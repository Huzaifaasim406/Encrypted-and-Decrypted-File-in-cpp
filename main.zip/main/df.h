#ifndef DF_H
#define DF_H

class dfe{
	public:
		void password_decrypt();
};
#endif
