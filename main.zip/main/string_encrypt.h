
#ifndef STRING_ENCRYPT_H
#define STRING_ENCRYPT_H

class password_encrypt{
	public:
		void encryption_password();
};
#endif /* EA3252FF_2E29_47CA_A023_41FCEBF68DEC */
