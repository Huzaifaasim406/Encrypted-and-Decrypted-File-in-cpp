#ifndef C1_H
#define C1_H

class file{
	public:
		void encryption_file();
};
#endif /* EA3252FF_2E29_47CA_A023_41FCEBF68DEC */
